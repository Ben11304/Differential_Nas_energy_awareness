import sys
sys.path.append('../')
# import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
sns.set(font_scale=1.2)
from matplotlib.lines import Line2D
from sklearn.preprocessing import MinMaxScaler, PolynomialFeatures, StandardScaler
from utils.data_utils import preprocess_and_normalize_energy_data, parse_codecarbon_output
from sklearn.linear_model import LinearRegression, Lasso
from utils.experiments_utils import split_data_set, fit_model, compute_log_transformed_features, apply_data_transforms, test_model
from sklearn.metrics import r2_score
%load_ext autoreload
%autoreload 2
SEED = 1234

models = {}
estimates = {}
d1 = parse_codecarbon_output(
    '../data/conv2d/00_conv2d-raw.csv',
    False,
    ('../data/conv2d/00_conv2d-slurm-log.out','conv2d',False,3)
)
print("dataset shape:", d1.shape)

d2 = parse_codecarbon_output(
    '../data/conv2d/02_conv2d-raw.csv',
    False,
    ('../data/conv2d/02_conv2d-slurm-log.out','conv2d',True,3)
)
print("dataset shape:", d2.shape)


param_cols = ['batch_size','image_size','kernel_size','in_channels','out_channels','stride','padding']
data_unnormalized = pd.concat([d1,d2])
print("dataset shape before aggregation: ", data_unnormalized.shape)
data = preprocess_and_normalize_energy_data(data_unnormalized, param_cols, aggregate=True)

print(f"Used features: {param_cols}")
dfs = split_data_set(data, param_cols, SEED, verbose=True)
transformers_dict = {
    "x_preprocessors": [PolynomialFeatures(degree=4, interaction_only=True)],
    "y_preprocessor": MinMaxScaler()
}
dfs, _ = apply_data_transforms(dfs, transformers_dict)
model, *_ = fit_model(Lasso(max_iter=int(1e5)), dfs["x_train"], dfs["y_train"], dfs["x_val"], dfs["y_val"], plot_results=False)