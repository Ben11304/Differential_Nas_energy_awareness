param_cols = ['batch_size','image_size','kernel_size','in_channels','out_channels','stride','padding']
data_unnormalized = pd.concat([d1,d2])
print("dataset shape before aggregation: ", data_unnormalized.shape)
data = preprocess_and_normalize_energy_data(data_unnormalized, param_cols, aggregate=True)

data_linear_with_log, param_cols_with_log = compute_log_transformed_features(data, param_cols)
# colum names
print(f"Used features: {param_cols_with_log}")
dfs = split_data_set(data_linear_with_log, param_cols_with_log, SEED)
transformers_dict = {
    "x_preprocessors": [PolynomialFeatures(degree=3, interaction_only=True)],
    "y_preprocessor": MinMaxScaler()
}
dfs, _ = apply_data_transforms(dfs, transformers_dict)
model, *_ = fit_model(Lasso(max_iter=int(1e5)), dfs["x_train"], dfs["y_train"], dfs["x_val"], dfs["y_val"], plot_results=False)